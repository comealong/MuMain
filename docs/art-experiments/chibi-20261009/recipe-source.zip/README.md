# Q版肩臂与手部修订实验

打开 Chibi_Anatomy_Experiment.blend。左侧为原始角色，右侧为新版 Q 版角色；右手保留原始武器。全部文件仅在本实验目录，未安装或覆盖游戏资源。

## 本次修订

- 每侧肩关节向内收 3.5 单位、下移 2 单位；上臂长度乘 1.15，前臂长度乘 1.25，改善上臂、护腕和手掌挤在一起的轮廓。
- 肩部从胸廓内部连续过渡到上臂，缩小肩帽和护腕，收紧腕部。
- 持剑手按源节点 33 的坐标系包住真实剑柄，重建手掌、四指与拇指；剑的父级挂接和 0.64 刚体缩放保持原设定。
- 空手采用稍向下垂的手掌、有厚度的掌背及微曲的四指，拇指位于身体内侧。
- 手套改为可辨认明暗的炭灰色材质，衣服、头部和腿部继续使用已有 Q 版贴图。

## 动画与文件范围

保留 60 个源节点、284 个动作以及原有旋转和位置增量曲线。调整的是骨架静置局部位移：子节点继承关节的新位置，手指和武器挂点一起移动。新手指几何绑定手骨，没有新增独立手指动画。

已有 BMD 来源元数据没有重写为新的骨架数据。本文件是 Blender 美术实验；不能把原有自动导出保留动作的功能视为这次比例修改已经正确导出。尚未进行完整动作审查或游戏运行验证。

## 查看效果

- previews/Chibi_Portrait.png：新版全身。
- previews/Shoulder_Front.png、Shoulder_Side.png：肩臂与手部细节。
- previews/Original_vs_Chibi.png：与原始角色同场对比。
- previews/standing.png、walking.png、sword_swing.png：动作 4/key 0、17/key 3、39/key 4 的静态抽样。
- report.json：输入文件哈希和场景清单。
- saved_surface_inspection.json：重新打开保存结果后记录的接缝和拓扑检查。

## 重建

使用 Blender 后台打开上一版 chibi_connected_20261009/Chibi_Connected_Experiment.blend，运行 scripts/build_connected.py，并在双横线后传入 --experiment 和本实验目录绝对路径。脚本中的 OUT 和 INPUT 是本机工作区路径。scripts/arm_anatomy.py 集中保存肩臂比例和手掌造型参数。
