# Q 版膝踝连接修复实验

输入：../chibi_anatomy_20261009/Chibi_Anatomy_Experiment.blend。
输出：Chibi_Joint_Blend_Experiment.blend。源文件与游戏数据未修改；保留原始角色同场对比和右手武器。

## 原因与修复

旧版大腿、靴筒和鞋面分别生成并封端。在膝盖处，倾斜不同的端面形成楔形凹槽；在脚踝处，靴筒只与圆鞋顶的少量表面相交。体素融合后这些体积已经拓扑连通，但侧面仍有近似分离的间隙观感。旧检查中的“一个连通分量、零开口边”不足以排除此问题。

本版只调整下肢的构造方法：用髋、膝、踝、鞋内点组成一条连续曲线路径，在膝、踝位置使用内部截面，不生成端盖；靴筒沿脚踝连续延伸进鞋内，再柔化鞋面过渡。保留银色靴口作为连续表面的材质区域。沿路径过渡大腿、小腿、脚的权重，拆分材质槽位时继续共享边界位置、权重与法线。

没有再次改变骨架比例或动作曲线，头、肩臂、手掌和武器沿用输入版本的构造参数。身体外壳由生成器重新求值，属于 Blender 美术实验；未完成 BMD 导出或游戏检查。

## 文件

- scripts/continuous_legs.py：本轮下肢连续表面与脚踝柔化。
- scripts/build_connected.py：基于输入骨架构造、渲染并另存；没有调用 revise_arm_rest，避免比例再次叠加。
- scripts/joint_views.py：相同镜头下的灰模和贴图对照。
- scripts/inspect_saved.py：保存后拓扑、边界及动作变形后的世界坐标接缝记录。
- previews/before_side_single.png、after_side_single.png：灰模侧面对照。
- previews/before_side_texture.png、after_side_texture.png：带贴图侧面对照。
- previews/pose_17_*、pose_39_*：行走与挥剑局部预览。
- report.json、saved_surface_inspection.json：本轮记录。检查器最终运行日志为 reopen_inspection_v02.log。

历史检查器首次缺少本地模块导入路径，已补齐并重跑；不把首次失败日志视为动作检查通过。
